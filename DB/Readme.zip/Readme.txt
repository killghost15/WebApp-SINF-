Abrir a pasta do sqlServer no programFiles e procurar a a pasta DATA copiar apenas a PriDEMOSINF se n funcionar copia o resto

